import React from "react";
// import jsonData from "./fullStackDev.json";
import "./Components/shadowCss.css";
import FullStackPage from "./Components/fullStackSection";

const App = () => {
  return (
    <>
      <FullStackPage />
    </>
  );
};

export default App;
